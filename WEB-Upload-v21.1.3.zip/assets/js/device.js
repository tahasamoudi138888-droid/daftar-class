async function enableNotifications(){
  if(!('Notification' in window)){ toast(tr('notification_unsupported')); return; }
  const permission=await Notification.requestPermission();
  data.settings.notifications=permission==='granted';
  await saveData({throwOnError:true});
  refreshSettingsModal();
  if(permission==='granted')checkPersonalReminderNotifications();
  toast(tr(permission==='granted'?'notification_enabled':'notification_denied'));
}
function disableNotifications(){
  data.settings.notifications=false;
  saveData(); refreshSettingsModal(); toast(tr('notification_disabled'));
}
async function installClassApp(){
  if(window.matchMedia('(display-mode: standalone)').matches){ toast(tr('install_already')); return; }
  if(!deferredInstallPrompt){ toast(tr('install_browser_hint')); return; }
  deferredInstallPrompt.prompt();
  await deferredInstallPrompt.userChoice;
  deferredInstallPrompt=null;
}
function appInstallPlatform(){
  const ua=navigator.userAgent||'';
  if(/iPad|iPhone|iPod/i.test(ua)||(navigator.platform==='MacIntel'&&navigator.maxTouchPoints>1))return 'ios';
  return /Android/i.test(ua)?'android':'desktop';
}
function suppliedApkMatchesSite(){
  return location.origin==='https://tahasamoudi138888-droid.github.io'&&/^\/daftar-kelas(?:\/|$)/.test(location.pathname);
}
function openAppDownloads(){
  const platform=appInstallPlatform(),installed=window.matchMedia('(display-mode: standalone)').matches||navigator.standalone===true;
  openModal(`<button type="button" class="modal-close-x" data-action="closeModal()" aria-label="${escapeAttr(tr('settings_close'))}">${ICON.x}</button>
    <div class="app-download-heading"><img src="icon-192.png" width="64" height="64" alt=""><div><h3>${tr('app_download_title')}</h3><p>${tr('app_download_hint')}</p></div></div>
    ${installed?`<p class="app-install-notice" role="status">${tr('install_already')}</p>`:''}
    <div class="app-download-platforms">
      <section class="app-download-card ${platform==='ios'?'recommended':''}" aria-labelledby="iosDownloadTitle"><span class="app-platform-name">iOS</span><h4 id="iosDownloadTitle">${tr('app_download_ios')}</h4><p>${tr('app_ios_hint')}</p>${platform==='ios'?`<small>${tr('app_device_recommended')}</small>`:''}<button type="button" class="btn btn-gold" data-action="showIosInstallGuide()">${tr('app_ios_action')}</button></section>
      <section class="app-download-card ${platform==='android'?'recommended':''}" aria-labelledby="androidDownloadTitle"><span class="app-platform-name">Android</span><h4 id="androidDownloadTitle">${tr('app_download_android')}</h4><p>${tr('app_android_hint')}</p>${platform==='android'?`<small>${tr('app_device_recommended')}</small>`:''}<button type="button" class="btn btn-gold" data-action="installAndroidWebApp()">${tr('app_android_action')}</button><button type="button" class="btn btn-outline-dark" data-action="showAndroidApkInfo()">${tr('app_apk_action')}</button></section>
    </div><p class="app-install-note">${tr('app_install_data_note')}</p>`);
}
function showIosInstallGuide(){
  openModal(`<button type="button" class="modal-close-x" data-action="closeModal()" aria-label="${escapeAttr(tr('settings_close'))}">${ICON.x}</button><h3>${tr('app_download_ios')}</h3><p class="app-install-note">${tr('app_ios_limit')}</p><ol class="app-install-steps"><li>${tr('app_ios_step1')}</li><li>${tr('app_ios_step2')}</li><li>${tr('app_ios_step3')}</li></ol><button type="button" class="btn btn-outline-dark" data-action="openAppDownloads()">${tr('aria_back')}</button>`);
}
async function installAndroidWebApp(){
  if(appInstallPlatform()==='ios'){showIosInstallGuide();return}
  if(deferredInstallPrompt){await installClassApp();openAppDownloads();return}
  if(window.matchMedia('(display-mode: standalone)').matches){toast(tr('install_already'));return}
  openModal(`<button type="button" class="modal-close-x" data-action="closeModal()" aria-label="${escapeAttr(tr('settings_close'))}">${ICON.x}</button><h3>${tr('app_download_android')}</h3><p class="app-install-note">${tr('app_android_manual')}</p><button type="button" class="btn btn-outline-dark" data-action="openAppDownloads()">${tr('aria_back')}</button>`);
}
function showAndroidApkInfo(){
  const matches=suppliedApkMatchesSite();
  openModal(`<button type="button" class="modal-close-x" data-action="closeModal()" aria-label="${escapeAttr(tr('settings_close'))}">${ICON.x}</button><h3>${tr('app_apk_action')}</h3><p class="app-install-note">${tr(matches?'app_apk_hint':'app_apk_old_site')}</p><p class="app-install-note">${tr('app_apk_permission')}</p><a class="btn btn-outline-dark app-apk-link" href="downloads/daftar-kelas-original.apk" download="daftar-kelas.apk">${tr(matches?'app_apk_download':'app_apk_download_old')}</a><button type="button" class="btn btn-gold" data-action="installAndroidWebApp()">${tr('app_android_action')}</button><button type="button" class="btn btn-outline-dark" data-action="openAppDownloads()">${tr('aria_back')}</button>`);
}
async function protectStoredData(){
  if(!navigator.storage||!navigator.storage.persist){ toast(tr('storage_persist_unsupported')); return; }
  const granted=await navigator.storage.persist();
  toast(tr(granted?'storage_persist_enabled':'storage_persist_denied'));
}
async function openStorageManager(){
  let estimate={usage:0,quota:0};
  try{if(navigator.storage&&navigator.storage.estimate)estimate=await navigator.storage.estimate()}catch(_){ }
  const books=data.classes.filter(c=>c.textbook),bookTotal=books.reduce((n,c)=>n+Number(c.textbook.size||0),0);
  const listeningItems=[];data.classes.forEach(c=>(c.listenings||[]).forEach(a=>listeningItems.push({c,a})));
  const listeningTotal=listeningItems.reduce((n,x)=>n+Number(x.a.size||0),0);
  let dataBytes=0;try{dataBytes=new TextEncoder().encode(JSON.stringify(data)).byteLength}catch(_){ }
  const mediaTotal=bookTotal+listeningTotal,percent=estimate.quota?Math.min(100,Math.round((estimate.usage/estimate.quota)*100)):0;
  const remaining=estimate.quota?Math.max(0,estimate.quota-estimate.usage):0;
  openModal(`<button type="button" class="modal-close-x" data-action="closeModal()" aria-label="${escapeAttr(tr('settings_close'))}">${ICON.x}</button><h3>${tr('storage_title')}</h3>
    <div class="storage-summary storage-summary-4">
      <div><b>${formatBytes(dataBytes)}</b><span>${tr('storage_data_size')}</span></div>
      <div><b>${formatBytes(bookTotal)}</b><span>${tr('storage_books_size')}</span></div>
      <div><b>${formatBytes(listeningTotal)}</b><span>${tr('storage_listening_size')}</span></div>
      <div><b>${estimate.quota?formatBytes(remaining):'—'}</b><span>${tr('storage_remaining')}</span></div>
    </div>
    ${estimate.quota?`<div class="storage-meter"><span data-style="width:${percent}%"></span></div><p class="storage-caption">${tr('storage_percent').replace('{percent}',percent)} · ${tr('storage_total_app').replace('{size}',formatBytes(estimate.usage))}</p>`:''}
    <div class="storage-total-line"><b>${formatBytes(mediaTotal)}</b><span>${tr('storage_media_total')}</span></div>
    <h2 class="section-title">${tr('storage_saved_books')}</h2>
    ${books.length?books.map(c=>`<div class="storage-book"><div class="textbook-icon">${ICON.book}</div><div><b>${escapeHtml(c.textbook.name)}</b><span>${escapeHtml(c.name)} · ${formatBytes(c.textbook.size)}</span></div><button class="hist-del" data-action="deleteStoredTextbook('${c.id}')" aria-label="${escapeAttr(tr('btn_delete'))}">${ICON.trash}</button></div>`).join(''):`<div class="empty-state"><p>${tr('storage_no_books')}</p></div>`}
    <h2 class="section-title">${tr('storage_saved_listening')}</h2>
    ${listeningItems.length?listeningItems.map(x=>`<div class="storage-book"><div class="textbook-icon">${ICON.audio}</div><div><b>${escapeHtml(listeningLabel(x.a))}</b><span>${escapeHtml(x.c.name)} · ${formatBytes(x.a.size)}</span></div><button class="hist-del" data-action="confirmDeleteListening('${x.c.id}','${x.a.id}')" aria-label="${escapeAttr(tr('btn_delete'))}">${ICON.trash}</button></div>`).join(''):`<div class="empty-state"><p>${tr('storage_no_listening')}</p></div>`}`);
}
function deleteStoredTextbook(cid){
  confirmModal(tr('textbook_delete'),tr('textbook_delete_confirm'),async()=>{const c=getClass(cid);if(!c)return;await idbDelete(textbookStorageKey(cid)).catch(()=>{});c.textbook=null;await saveData({throwOnError:true});toast(tr('textbook_removed'));openStorageManager()});
}
